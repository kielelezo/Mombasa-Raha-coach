function bookNow(productName) {
  document.getElementById("product").value = productName;
  window.location.href = "#booking";
}

document.getElementById("mpesaForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const phone = document.getElementById("phone").value;
  const product = document.getElementById("product").value;
  const amount = document.getElementById("amount").value;

  alert(\`Thank you \${name}! We’ve received your booking for "\${product}". Pay KES \${amount} via M-Pesa and we’ll confirm shortly.\`);

  this.reset();
});
